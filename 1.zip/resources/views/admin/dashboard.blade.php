@extends('layouts.admin')
@section('content')

<h1>You are in Dashboard</h1>
@endsection

