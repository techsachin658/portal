@extends('layouts.admin')
@section('content')
    <h1>You are in User Section</h1>
@endsection
