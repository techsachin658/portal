<?php $__env->startSection('content'); ?>

<h1>You are in Dashboard</h1>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/raaj/portal/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>